"use client";

import Link from 'next/link';

export default function ProgramPage() {
  return (
    <main className="min-h-screen bg-slate-50 text-slate-800 py-16 px-8 font-sans">
      <div className="max-w-6xl mx-auto space-y-16">
        
        {/* Buton Înapoi */}
        <div>
          <Link href="/" className="inline-flex items-center text-red-600 font-semibold mb-2 hover:underline gap-2">
            ← Înapoi la pagina principală
          </Link>
        </div>

        {/* Header Pagina */}
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <span className="bg-red-50 text-red-600 font-bold px-4 py-1.5 rounded-full text-xs uppercase tracking-wider">
            Informații utile pacienți
          </span>
          <h1 className="text-4xl md:text-5xl font-black tracking-tight text-slate-900">
            Programul Clinicii & Politici
          </h1>
          <p className="text-slate-500 text-lg">
            Tot ce trebuie să știi înainte de vizita ta la CardioNova, de la orarul general până la durata investigațiilor.
          </p>
        </div>

        {/* 1. ORAR GENERAL ȘI GARANȚIA CABINETELOR */}
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100 flex flex-col justify-between space-y-6">
            <div>
              <h3 className="text-xl font-bold text-slate-900 mb-1">Orar de Funcționare</h3>
              <p className="text-xs text-slate-400 mb-6">Disponibilitate clinici și recepție</p>
              
              <div className="space-y-3 font-semibold text-sm">
                <div className="flex justify-between border-b border-slate-100 pb-2">
                  <span className="text-slate-500">Luni - Vineri</span>
                  <span className="text-red-600">08:00 - 20:00</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 pb-2">
                  <span className="text-slate-500">Schimbul I</span>
                  <span className="text-slate-700">08:00 - 14:00</span>
                </div>
                <div className="flex justify-between border-b border-slate-100 pb-2">
                  <span className="text-slate-500">Schimbul II</span>
                  <span className="text-slate-700">14:00 - 20:00</span>
                </div>
                <div className="flex justify-between text-slate-400 pt-1">
                  <span>Sâmbătă - Duminică</span>
                  <span className="font-bold">Închis</span>
                </div>
              </div>
            </div>
            
            <p className="text-xs text-slate-400 bg-slate-50 p-3 rounded-xl italic">
              * Programul medicilor este organizat prin rotație, pentru asigurarea continuității activității medicale și reducerea timpului de așteptare.
            </p>
          </div>

          <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-3xl p-8 text-white md:col-span-2 shadow-md space-y-6">
            <div>
              <h3 className="text-2xl font-bold tracking-tight">Acoperire Medicală Permanentă</h3>
              <p className="text-slate-400 text-sm mt-1">În fiecare interval orar, pentru siguranța dumneavoastră, în clinică sunt disponibile:</p>
            </div>
            
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="bg-white/5 p-4 rounded-2xl border border-white/5 space-y-1">
                <span className="text-xl">🩺</span>
                <h4 className="font-bold text-sm">Cardiologie Generală</h4>
                <p className="text-xs text-slate-400">Minimum 2 cabinete active simultan.</p>
              </div>
              <div className="bg-white/5 p-4 rounded-2xl border border-white/5 space-y-1">
                <span className="text-xl">🖥️</span>
                <h4 className="font-bold text-sm">Imagistică Cardiovasculară</h4>
                <p className="text-xs text-slate-400">1 cabinet complet de înaltă performanță.</p>
              </div>
              <div className="bg-white/5 p-4 rounded-2xl border border-white/5 space-y-1">
                <span className="text-xl">⚡</span>
                <h4 className="font-bold text-sm">Evaluare Intervențională</h4>
                <p className="text-xs text-slate-400">Acces direct sau electrofiziologic prin programare.</p>
              </div>
              <div className="bg-white/5 p-4 rounded-2xl border border-white/5 space-y-1">
                <span className="text-xl">🛡️</span>
                <h4 className="font-bold text-sm">Suport Specializat ATI</h4>
                <p className="text-xs text-slate-400">Asistență permanentă pentru proceduri minim invazive.</p>
              </div>
            </div>
          </div>
        </div>

        {/* 2. DURATA ESTIMATĂ A CONSULTAȚIILOR */}
        <div className="bg-white rounded-3xl p-8 md:p-10 shadow-sm border border-slate-100 space-y-6">
          <div>
            <h3 className="text-2xl font-bold text-slate-900">Durata Estimată a Consultațiilor</h3>
            <p className="text-slate-500 text-sm">Fiecare pacient primește atenție completă, fără grabă, în funcție de specificul investigației.</p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { tip: "Consultație Cardiologie Generală", timp: "30 minute", icon: "❤️" },
              { tip: "Consultație Cardiologie Complexă", timp: "45 minute", icon: "🔍" },
              { tip: "Ecocardiografie", timp: "30-45 minute", icon: "🔊" },
              { tip: "Consultație Insuficiență Cardiacă", timp: "45 minute", icon: "🫁" },
              { tip: "Evaluare Electrofiziologică", timp: "45-60 minute", icon: "⚡" },
              { tip: "Holter ECG / TA", timp: "20 minute", icon: "📊" },
              { tip: "Consultație Chirurgie Vasculară", timp: "30-45 minute", icon: "🩸" },
              { tip: "Consultație Diabetologie", timp: "30 minute", icon: "🍏" },
              { tip: "Consultație de Control", timp: "20-30 minute", icon: "📋" },
            ].map((item, idx) => (
              <div key={idx} className="flex items-center gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                <span className="text-xl bg-white p-2.5 rounded-xl shadow-sm border border-slate-100">{item.icon}</span>
                <div>
                  <h4 className="text-xs font-bold text-slate-800 leading-tight">{item.tip}</h4>
                  <span className="text-xs text-red-600 font-bold block mt-0.5">{item.timp}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 3. REGULI ȘI POLITICI INTERNE */}
        <div className="grid md:grid-cols-2 gap-8">
          {/* Întârzieri */}
          <div className="bg-red-50/40 rounded-3xl p-8 border border-red-100/70 space-y-4">
            <div className="flex items-center gap-3">
              <span className="text-2xl">⏰</span>
              <h3 className="text-lg font-bold text-slate-900">Politica privind Întârzierile</h3>
            </div>
            <ul className="space-y-3 text-slate-600 text-sm font-medium">
              <li className="flex items-start gap-2">
                <span className="text-red-500 mt-0.5">•</span> Pacienții sunt rugați să se prezinte cu **minimum 15 minute înainte** de ora stabilită.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-500 mt-0.5">•</span> Întârzierile mai mari de **15 minute** pot duce direct la reprogramarea consultației, pentru a nu decala restul pacienților.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-500 mt-0.5">•</span> În situații medicale urgente, programul poate suferi modificări operaționale independente de noi.
              </li>
            </ul>
          </div>

          {/* Anulări */}
          <div className="bg-amber-50/40 rounded-3xl p-8 border border-amber-100/70 space-y-4">
            <div className="flex items-center gap-3">
              <span className="text-2xl">📅</span>
              <h3 className="text-lg font-bold text-slate-900">Politica de Anulare & Programare</h3>
            </div>
            <ul className="space-y-3 text-slate-600 text-sm font-medium">
              <li className="flex items-start gap-2">
                <span className="text-amber-600 mt-0.5">•</span> Programările se fac la recepție, telefonic, prin e-mail sau direct pe platforma online a clinicii.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-600 mt-0.5">•</span> Anulările sau reprogramările trebuie anunțate obligatoriu cu **minimum 24 de ore înainte**.
              </li>
              <li className="flex items-start gap-2">
                <span className="text-amber-600 mt-0.5">•</span> Consultațiile neanunțate din timp pot fi taxate conform regulamentului intern al clinicii.
              </li>
            </ul>
          </div>
        </div>

      </div>
    </main>
  );
}