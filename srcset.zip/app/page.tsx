"use client";

import { useState } from "react";
import Link from "next/link";

export default function Home() {
  // Stări pentru controlul formularului de date personale
  const [arataFormular, setArataFormular] = useState(false);
  const [nume, setNume] = useState("");
  const [telefon, setTelefon] = useState("");
  const [email, setEmail] = useState("");
  const [data, setData] = useState("");
  const [mesaj, setMesaj] = useState("");
  const [succes, setSucces] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nume || !telefon || !email || !data) {
      alert("Te rugăm să completezi toate câmpurile obligatorii (*).");
      return;
    }
    setSucces(true);
  };

  const reseteazaFormular = () => {
    setNume("");
    setTelefon("");
    setEmail("");
    setData("");
    setMesaj("");
    setSucces(false);
    setArataFormular(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800 relative scroll-smooth">
      
      {/* MENIUL DE SUS (NAVBAR) */}
      <header className="sticky top-0 bg-white/90 backdrop-blur-md border-b border-slate-100 z-40 shadow-sm">
        <div className="flex items-center justify-between px-8 py-4 max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <img src="/logo.png" alt="Logo CardioNova" className="w-12 h-12 object-contain" />
            <div>
              <span className="text-xl font-black tracking-tight text-slate-900 block">CardioNova</span>
              <span className="text-xs text-slate-400 block -mt-1 font-medium">Servicii Heart Touching</span>
            </div>
          </div>
          <nav className="flex gap-8 font-semibold text-slate-600">
            <Link href="/program" className="hover:text-red-600 transition">Program</Link>
            <Link href="/echipa" className="hover:text-red-600 transition">Doctori</Link>
            <Link href="/contact" className="hover:text-red-600 transition">Contact</Link>
          </nav>
        </div>
      </header>

      {/* 1. ZONA PRINCIPALA (HERO SECTION) */}
      <section className="max-w-7xl mx-auto px-8 py-16 md:py-24 grid md:grid-cols-2 gap-12 items-center bg-white rounded-3xl mt-6 shadow-sm border border-slate-100">
        <div className="space-y-6">
          <div className="inline-flex items-center gap-2 bg-red-50 text-red-700 text-xs font-bold px-3 py-1.5 rounded-full border border-red-100">
            📍 Locație centrală: Strada Justinian 3, București
          </div>
          <h1 className="text-4xl md:text-6xl font-black text-slate-950 tracking-tight leading-none">
            Clinica modernă pentru <span className="text-red-600">sănătatea inimii</span> tale
          </h1>
          <p className="text-slate-500 text-base md:text-lg font-medium max-w-md">
            Un singur centru dedicat diagnosticului rapid, deciziei multidisciplinare imediate și tratamentului cardiovascular integrat.
          </p>
          <div>
            <button 
              onClick={() => setArataFormular(true)}
              className="inline-block bg-red-600 text-white font-bold px-8 py-4 rounded-2xl shadow-lg shadow-red-200 hover:bg-red-700 transition-all transform hover:-translate-y-0.5"
            >
              Programează-te Online Acum ❤️
            </button>
          </div>
        </div>

        {/* Card Angajamente Clinice */}
        <div className="bg-gradient-to-br from-red-500 to-rose-600 rounded-[2.5rem] p-8 md:p-10 text-white shadow-xl space-y-4">
          <h3 className="text-2xl font-black tracking-tight">Standarde de Excelență</h3>
          <p className="text-red-100 text-xs font-medium -mt-2">Angajamentele noastre clinice măsurabile:</p>
          <ul className="space-y-3 font-semibold text-xs md:text-sm">
            <li className="bg-white/10 backdrop-blur-md px-5 py-3 rounded-2xl border border-white/10">
              🚨 <strong>Standardul STEMI Sub 60 Min</strong> – Timpul de la prezentare la deschiderea arterei coronare.
            </li>
            <li className="bg-white/10 backdrop-blur-md px-5 py-3 rounded-2xl border border-white/10">
              👥 <strong>Comisie Cardiometabolică Săptămânală</strong> – Abordare integrată pentru cazurile cu comorbidități complexe.
            </li>
          </ul>
        </div>
      </section>

      {/* ================= SECTIUNEA DETALIATĂ PREZENTARE CU IMAGINI INTERCALATE ================= */}
      <section className="max-w-7xl mx-auto px-4 py-16 space-y-24">
        
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <h2 className="text-3xl font-black tracking-tight text-slate-900 sm:text-4xl">Descoperă Clinica CardioNova</h2>
          <p className="text-slate-500 font-medium">Parcurge traseul complet al serviciilor noastre integrate prin intermediul echipei și dotărilor noastre.</p>
        </div>

        {/* POZA 1: POZA GRUP (STÂNGA IMAGINE - DREAPTA TEXT) */}
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="w-full h-80 bg-slate-900 rounded-3xl relative overflow-hidden border border-slate-200 shadow-md group">
            <img src="/poza grup.jpeg" alt="Echipa Medicala" className="object-cover w-full h-full group-hover:scale-105 transition duration-500" onError={(e) => { e.currentTarget.style.display = 'none'; }} />
            <div className="absolute inset-0 bg-slate-950/40 p-6 flex items-end text-white text-xs font-mono">Fișier: poza grup.jpeg</div>
          </div>
          <div className="space-y-4">
            <span className="bg-red-100 text-red-700 font-bold text-xs uppercase px-3 py-1 rounded-full">01. Echipa Noastră</span>
            <h3 className="text-2xl font-black text-slate-900 tracking-tight">Oameni dedicați inimii tale</h3>
            <p className="text-slate-600 leading-relaxed font-medium">
              Echipa CardioNova reunește medici primari cardiologi de renume, chirurgi vasculari de elită și medici diabetologi. Aceștia colaborează strâns în cadrul comisiilor multidisciplinare săptămânale pentru a crea planuri terapeutice personalizate, eliminând complet fragmentarea serviciilor medicale clasice.
            </p>
          </div>
        </div>

        {/* POZA 2: POZA OPERATIE (DREAPTA IMAGINE - STÂNGA TEXT) */}
        <div className="grid md:grid-cols-2 gap-12 items-center md:flex-row-reverse">
          <div className="space-y-4 md:order-1">
            <span className="bg-red-100 text-red-700 font-bold text-xs uppercase px-3 py-1 rounded-full">02. Intervenții și Bloc Operator</span>
            <h3 className="text-2xl font-black text-slate-900 tracking-tight">Tehnologie chirurgicală minim invazivă</h3>
            <p className="text-slate-600 leading-relaxed font-medium">
              Blocul nostru operator include o sală de electrofiziologie ultramodernă echipată cu sisteme de mapping 3D de ultimă generație. Aici se efectuează cu succes proceduri avansate precum ablații de fibrilație atrială, implanturi TAVI și revascularizări coronariene complexe.
            </p>
          </div>
          <div className="w-full h-80 bg-slate-900 rounded-3xl relative overflow-hidden border border-slate-200 shadow-md group md:order-2">
            <img src="/poza operatie.png" alt="Bloc Operator" className="object-cover w-full h-full group-hover:scale-105 transition duration-500" onError={(e) => { e.currentTarget.style.display = 'none'; }} />
            <div className="absolute inset-0 bg-slate-950/40 p-6 flex items-end text-white text-xs font-mono">Fișier: poza operatie.png</div>
          </div>
        </div>

        {/* POZA 3: POZA VAIII (STÂNGA IMAGINE - DREAPTA TEXT) */}
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="w-full h-80 bg-slate-900 rounded-3xl relative overflow-hidden border border-slate-200 shadow-md group">
            <img src="/poza vaiii.jpeg" alt="Echipamente" className="object-cover w-full h-full group-hover:scale-105 transition duration-500" onError={(e) => { e.currentTarget.style.display = 'none'; }} />
            <div className="absolute inset-0 bg-slate-950/40 p-6 flex items-end text-white text-xs font-mono">Fișier: poza vaiii.jpeg</div>
          </div>
          <div className="space-y-4">
            <span className="bg-red-100 text-red-700 font-bold text-xs uppercase px-3 py-1 rounded-full">03. Diagnostic de Înaltă Performanță</span>
            <h3 className="text-2xl font-black text-slate-900 tracking-tight">Investigații rapide și precise</h3>
            <p className="text-slate-600 leading-relaxed font-medium">
              Dispunem de sisteme avansate pentru teste de efort, ecocardiografie 2D/3D transtoracică și transesofagiană, dispozitive de monitorizare Holter ECG și MAPA. Toate investigațiile sunt conectate la o fișă electronică unică pentru accelerarea deciziilor critice.
            </p>
          </div>
        </div>

        {/* POZA 4: POZA TATUAT (DREAPTA IMAGINE - STÂNGA TEXT) */}
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-4">
            <span className="bg-red-100 text-red-700 font-bold text-xs uppercase px-3 py-1 rounded-full">04. Recuperare și Terapie Intensivă</span>
            <h3 className="text-2xl font-black text-slate-900 tracking-tight">Monitorizare și suport continuu</h3>
            <p className="text-slate-600 leading-relaxed font-medium">
              Clinica găzduiește un compartiment modern cu 8 paturi ATI dotat cu sisteme avansate de monitorizare hemodinamică continuă. De la ieșirea din operație și până la programul dedicat de recuperare cardiovasculară, pacientul rămâne complet securizat.
            </p>
          </div>
          <div className="w-full h-80 bg-slate-900 rounded-3xl relative overflow-hidden border border-slate-200 shadow-md group">
            <img src="/poza tatuat.jpeg" alt="Monitorizare" className="object-cover w-full h-full group-hover:scale-105 transition duration-500" onError={(e) => { e.currentTarget.style.display = 'none'; }} />
            <div className="absolute inset-0 bg-slate-950/40 p-6 flex items-end text-white text-xs font-mono">Fișier: poza tatuat.jpeg</div>
          </div>
        </div>

      </section>

      {/* FOOTER INFORMATIV */}
      <footer className="bg-slate-900 text-slate-400 py-8 px-8 border-t border-slate-800 text-center text-xs mt-12">
        <p>© 2026 CardioNova SRL. Adresă: Strada Justinian 3, București. Toate drepturile rezervate.</p>
      </footer>

      {/* FERESTRA MODALĂ (FORMULARUL DE DATE PERSONALE) */}
      {arataFormular && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden max-w-md w-full my-8 animate-fade-in">
            
            <div className="bg-gradient-to-r from-red-600 to-rose-600 p-6 text-white text-center relative">
              <button onClick={reseteazaFormular} className="absolute top-4 right-4 text-white/80 hover:text-white text-xl font-bold bg-white/10 w-8 h-8 rounded-full flex items-center justify-center transition">✕</button>
              <h2 className="text-xl font-black tracking-tight">Programare Rapidă Online</h2>
              <p className="text-red-100 text-xs font-medium mt-1">Lăsați datele dvs. personale mai jos.</p>
            </div>

            {succes ? (
              <div className="p-8 text-center space-y-4">
                <div className="text-3xl mx-auto bg-emerald-500 text-white w-14 h-14 rounded-full flex items-center justify-center font-bold shadow-md">✓</div>
                <h3 className="text-xl font-black text-emerald-950">Cerere Trimisă!</h3>
                <p className="text-slate-600 text-sm">Mulțumim, <strong>{nume}</strong>. Datele dvs. au fost înregistrate.</p>
                <p className="text-xs text-slate-400 font-medium bg-slate-50 p-3 rounded-xl border border-slate-100">Recepția vă va contacta la numărul <strong>{telefon}</strong> în maximum 15 minute pentru stabilirea orei.</p>
                <button onClick={reseteazaFormular} className="w-full bg-emerald-600 text-white text-sm font-bold py-3 rounded-xl hover:bg-emerald-700 transition">Închide</button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="p-6 space-y-4">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Nume complet *</label>
                  <input type="text" placeholder="Popescu Ioan" value={nume} onChange={(e) => setNume(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-red-500 font-medium" required />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Număr Telefon *</label>
                  <input type="tel" placeholder="07xxxxxxxx" value={telefon} onChange={(e) => setTelefon(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-red-500 font-medium" required />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Adresă Email *</label>
                  <input type="email" placeholder="ioan@email.com" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-red-500 font-medium" required />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Data dorită *</label>
                  <input type="date" value={data} onChange={(e) => setData(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-red-500 font-semibold text-slate-600" required />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Observații</label>
                  <textarea placeholder="Mențiuni opționale..." rows={2} value={mesaj} onChange={(e) => setMesaj(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-red-500 font-medium resize-none" />
                </div>
                <button type="submit" className="w-full bg-red-600 text-white font-bold py-3.5 rounded-xl shadow-lg hover:bg-red-700 transition mt-2 text-sm">Trimite Cererea 🔒</button>
              </form>
            )}
          </div>
        </div>
      )}

    </div>
  );
}