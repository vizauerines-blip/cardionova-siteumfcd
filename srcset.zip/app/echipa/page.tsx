"use client";
import Link from 'next/link';

export default function Echipa() {
  // Aici poți adăuga oricâți medici vrei din PowerPoint.
  // Doar pui o virgulă după ultima acoladă și adaugi un bloc nou.
  const doctors = [
    {
      name: "Dr. Voicu Radu",
      specialty: "Medic primar cardiologie",
      image: "/radu.jpeg", // Poza trebuie pusă în folderul 'public'
      bio: "Medic primar cu o vastă experiență în cardiologia clinică. Specializat în diagnosticul și tratamentul insuficienței cardiace și al hipertensiunii arteriale complexe.",
      education: ["Facultatea de Medicină UMF Carol Davila", "Membru al Societății Europene de Cardiologie"]
    },
    {
      name: "Dr. Vizauer Ines-Alexandra",
      specialty: "Imagistică cardiovasculară avansată",
      image: "/ines.jpeg", // Poza trebuie pusă în folderul 'public'
      bio: "Expert în tehnici moderne de diagnostic neinvaziv. Specializată în ecocardiografie transesofagiană, RM cardiac și CT de artere coronare.",
      education: ["Stagii internaționale de supraspecializare", "Membru în Asociația Europeană de Imagistică Cardiovasculară"]
    },
    {
      name: "Dr. Verdeș Mihaela-Cristiana",
      specialty: "Cardiologie intervențională",
      image: "/mihaela.jpeg", // Poza trebuie pusă în folderul 'public'
      bio: "Specializată în proceduri endovasculare și intervenții minim invazive. Expertiză recunoscută în coronarografii și angioplastii cu montare de stent.",
      education: ["Doctor în științe medicale", "Membru al Societății Române de Cardiologie Intervențională"]
    },
    {
      name: "Dr. Voica Eleonora",
      specialty: "Cardiologie",
      image: "/nora.jpeg",
      bio: "Medic specialist dedicat cardiologiei clinice, cu o abordare axată pe prevenția primară și secundară a bolilor de inimă[cite: 2, 28]. Coordonează protocoalele de monitorizare pentru pacienții cronici, oferind soluții moderne pentru managementul dislipidemiei și controlul factorilor de risc cardiovascular[cite: 51, 52].",
      education: ["Medic Specialist Cardiologie [cite: 2, 28]", "Competență în Ecocardiografie Transtoracică [cite: 57]"]
    },
    {
      name: "Dr. Voicu Alexandra-Elena",
      specialty: "Cardiologie",
      image: "/alexandra.jpeg",
      bio: "Specializată în evaluarea completă a aparatului cardiovascular și managementul terapeutic al hipertensiunii arteriale[cite: 2, 49, 28]. Se remarcă prin atenția deosebită acordată istoricului medical al fiecărui pacient și prin realizarea de planuri personalizate pentru prevenția afecțiunilor cardiace[cite: 50].",
      education: ["Medic Specialist Cardiologie [cite: 2, 28]", "Participări active la congrese medicale naționale și europene"]
    },
    {
      name: "Dr. Yuksel Irem Goksu",
      specialty: "Cardiologie",
      image: "/irem.jpeg",
      bio: "Asigură consultații cardiologice detaliate și investigații non-invazive esențiale precum ECG și monitorizări Holter[cite: 2, 48, 54, 55, 28]. Are o vastă pregătire clinică axată pe stabilizarea schemelor de tratament și ghidarea pacienților cu patologii cardiovasculare cronice[cite: 52].",
      education: ["Medic Specialist Cardiologie [cite: 2, 28]", "Supraspecializare în tehnici moderne de monitorizare de ritm și TA [cite: 55, 56]"]
    },
    {
      name: "Dr. Allagulyyeva Mahri",
      specialty: "Cardiologie",
      image: "/nurana.jpeg",
      bio: "Dedicată diagnosticării timpurii a bolilor cardiace, Dr. Mahri este expertă în corelarea semnelor clinice cu investigațiile paraclinice[cite: 2, 28]. Gestionează cu succes cazurile complexe de hipertensiune arterială și dislipidemii, punând accent pe educația medicală a pacientului[cite: 49, 51].",
      education: ["Medic Specialist Cardiologie [cite: 2, 28]", "Membru al asociațiilor internaționale de profil"]
    },
    {
      name: "Dr. Vlad Raluca-Elena",
      specialty: "Imagistică cardiovasculară avansată",
      image: "/elena.jpeg",
      bio: "Expertă în vizualizarea detaliată a structurilor inimii prin tehnici imagistice de înaltă performanță[cite: 2, 59, 28]. Munca ei oferă suportul diagnostic esențial pentru cazurile complexe, asigurând o corelare perfectă între imagistică și decizia de intervenție chirurgicală sau intervențională[cite: 23, 24].",
      education: ["Medic Specialist Cardiologie [cite: 2, 28]", "Supraspecializare în Imagistică Cardiovasculară Avanasată [cite: 2, 59, 28]"]
    },
    {
      name: "Dr. Vintilă Marian-Cosmin",
      specialty: "Cardiologie intervențională",
      image: "/cosmin.jpeg",
      bio: "Specializat în proceduri endovasculare salvatoare de vieți[cite: 2, 28]. Are o experiență recunoscută în efectuarea coronarografiilor și în angioplastia coronariană cu implantare de stent, restabilind rapid funcția optimă a arterelor inimii[cite: 61, 62, 63].",
      education: ["Medic Specialist Cardiologie [cite: 2, 28]", "Atestat în Cardiologie Intervențională [cite: 2, 60, 28]"]
    },
    {
      name: "Dr. Vlaston Ioana",
      specialty: "Electrofiziologie și aritmologie",
      image: "/ioana v.jpeg",
      bio: "Specialista clinicii în studiul și tratamentul tulburărilor de ritm cardiac[cite: 2, 65, 28]. Se ocupă cu evaluarea detaliată a aritmiilor, monitorizarea complexă a pacienților și programarea sau urmărirea dispozitivelor cardiace implantate (pacemaker)[cite: 66, 67, 68].",
      education: ["Medic Specialist Cardiologie [cite: 2, 28]", "Supraspecializare în Electrofiziologie și Implant de Dispozitive Cardiace [cite: 2, 68, 28]"]
    },
    {
      name: "Dr. Vieru Ana-Maria",
      specialty: "Insuficienţă cardiacă avansată",
      image: "/ana.jpeg",
      bio: "Dedicată exclusiv pacienților care se confruntă cu stadii severe de insuficiență cardiacă[cite: 2, 28]. Dr. Vieru elaborează scheme terapeutice complexe de ultimă generație și monitorizează strict evoluția pacienților pentru a le îmbunătăți considerabil calitatea vieții[cite: 52].",
      education: ["Medic Specialist Cardiologie [cite: 2, 28]", "Competență specifică în managementul Insuficienței Cardiace Avanasate [cite: 2, 28]"]
    },
    {
      name: "Dr. Vlăduţ Anastasia-Simona",
      specialty: "Chirurgie vasculară",
      image: "/anastasia.jpeg",
      bio: "Expertă în managementul bolilor sistemului circulator periferic arterial și venos[cite: 2, 69, 28]. Realizează ecografii Doppler vasculare de mare precizie, screening carotidian și oferă soluții terapeutice moderne pentru insuficiența venoasă cronică[cite: 71].",
      education: ["Medic Specialist Chirurgie Vasculară [cite: 2, 28]", "Competență în Ecografie Doppler Vasculară [cite: 71]"]
    },
    {
      name: "Dr. Vijială Evelin-Andreea",
      specialty: "Diabetologie şi nutriție",
      image: "/andreea.jpeg",
      bio: "Asigură managementul integrat al diabetului zaharat și al tulburărilor metabolice, elemente vitale pentru pacienții cu risc cardiovascular crescut[cite: 2, 72, 73, 28]. Construiește planuri nutriționale personalizate și strategii terapeutice de protecție a vaselor de sânge[cite: 73, 74].",
      education: ["Medic Specialist Diabet zaharat, nutriție și boli metabolice [cite: 2, 72, 28]"]
    },
    {
      name: "Dr. Vintilă Ioana",
      specialty: "Medic specialist ATI",
      image: "/ioana.jpeg",
      bio: "Asigură suportul vital esențial și monitorizarea funcțiilor critice în timpul procedurilor medicale din clinică[cite: 2, 26, 28]. Rolul ei este de a garanta siguranța maximă și confortul pacienților supuși investigațiilor sau intervențiilor de cardiologie intervențională[cite: 26].",
      education: ["Medic Specialist Anestezie și Terapie Intensivă (ATI) [cite: 2, 28]"]
    },
    {
      name: "Dr. Vlad Sara",
      specialty: "Medic rezident cardiologie",
      image: "/sara.jpeg",
      bio: "Tânăr medic dinamic și implicat activ în viața clinicii[cite: 2, 28]. Participă la monitorizarea pacienților internați sau veniți la control și la realizarea investigațiilor inițiale, desfășurându-și activitatea sub coordonarea directă a medicilor primari ai clinicii[cite: 2, 52, 28].",
      education: ["Medic Rezident Cardiologie [cite: 2, 28]", "Absolventă de top a Facultății de Medicină"]
    }
  ];

  return (
    <main className="min-h-screen bg-slate-50 text-slate-800 py-16 px-8">
      <div className="max-w-5xl mx-auto">
        
        {/* Buton de întoarcere */}
        <Link href="/" className="inline-flex items-center text-red-600 font-semibold mb-10 hover:underline gap-2">
          ← Înapoi la pagina principală
        </Link>

        <div className="mb-16">
          <h1 className="text-4xl md:text-5xl font-black tracking-tight mb-4 text-slate-900">
            Echipa Medicală CardioNova
          </h1>
          <p className="text-lg text-slate-500">
            Faceți cunoștință cu specialiștii noștri. Date preluate direct din prezentarea clinicii.
          </p>
        </div>

        {/* Generarea automată a listei pentru toți medicii */}
        <div className="space-y-12">
          {doctors.map((doctor, index) => (
            <div key={index} className="bg-white rounded-3xl p-8 shadow-md border border-slate-100 grid md:grid-cols-3 gap-8 items-center">
              
              {/* Imaginea medicului */}
              <div className="w-full aspect-square md:h-56 md:w-56 rounded-2xl overflow-hidden bg-slate-100 border-4 border-slate-50 shadow-md mx-auto">
                <img 
                  src={doctor.image} 
                  alt={doctor.name} 
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    // Imagine de rezervă dacă poza nu a fost încă mutată în folderul public
                    e.currentTarget.src = "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?q=80&w=400";
                  }}
                />
              </div>

              {/* Descrierea și educația */}
              <div className="md:col-span-2 space-y-4">
                <div>
                  <h2 className="text-2xl font-bold text-slate-900">{doctor.name}</h2>
                  <p className="text-red-600 font-semibold text-sm">{doctor.specialty}</p>
                </div>
                
                <p className="text-slate-600 leading-relaxed text-base">{doctor.bio}</p>
                
                <div className="pt-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Pregătire & Afilieri</h4>
                  <ul className="space-y-1">
                    {doctor.education.map((edu, i) => (
                      <li key={i} className="text-sm text-slate-700 flex items-center gap-2">
                        <span className="text-red-500">•</span> {edu}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>
    </main>
  );
}